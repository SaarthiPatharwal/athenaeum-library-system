# Athenaeum — Library Management System

A console-based library management system written in C++ (STL-backed), paired with a matching front-end concept: a marketing homepage, catalog UI, and login page.

## Contents

```
├── src/
│   └── LibraryManagementSystem.cpp   # C++ console application
├── web/
│   ├── index.html                    # Marketing / landing homepage
│   ├── athenaeum-library.html        # Interactive catalog UI (front-end demo)
│   └── athenaeum-login.html          # Login page (front-end demo)
└── docs/
    └── Final_report_LMS.pdf          # Full project report
```

## C++ application

A menu-driven console app for managing a small library's book inventory:

- Add, delete, and search books by title, author, or ISBN
- Issue and return copies, with availability tracked automatically
- Catalog view sortable by title, author, or ID
- All data persisted to `library_data.txt` between runs
- Robust input validation — invalid menu choices never crash or hang the program

### Build & run

```bash
g++ -std=c++17 -O2 -Wall -o library src/LibraryManagementSystem.cpp
./library
```

Requires a C++17-capable compiler (e.g. g++ 8+, clang 7+).

### Architecture

- **`Book`** — data model for a single title (ID, title, author, ISBN, quantities)
- **`LibraryManager`** — owns the catalog (`std::map<int, Book>` + `std::map<string,int>` ISBN index), and exposes every operation: add/delete/search/issue/return/sort/persist
- Sorting uses `std::vector<Book>` + `std::sort` with custom comparators
- Persistence uses `fstream`, in a simple pipe-delimited file format

## Web pages (front-end demo)

Static, self-contained HTML/CSS/JS pages — no build step, no dependencies. Open any file directly in a browser.

- **`web/index.html`** — landing page with hero, "how it works," features, and CTAs
- **`web/athenaeum-library.html`** — searchable/sortable catalog with issue/return/add actions (data lives in-memory for the session)
- **`web/athenaeum-login.html`** — sign-in page (demo credentials: any email + password `demo123`) that redirects into the catalog

> Note: the web pages are a front-end concept and are not currently wired to the C++ backend's data file.

## Report

`docs/Final_report_LMS.pdf` contains the full project write-up: abstract, objectives, system design, architecture diagram, testing, and results.

## License

Add a license of your choice (e.g. MIT) if you plan to make this public.
